<!--
 * Author Bakaran Project
 * Made by Trian Damai
 * 28 Jan 2021 - 10:14
 *
 --->
<template>
  <div class="card card-custom gutter-b card-stretch card-shadowless bg-white">
    <div class="card-body p-0 d-flex">
      <div
        class="d-flex align-items-start justify-content-start flex-grow-1 bg-light-warning p-8 card-rounded flex-grow-1 position-relative"
      >
        <div class="d-flex flex-column align-items-start flex-grow-1 h-100">
          <div class="p-1 flex-grow-1">
            <h4 class="text-warning font-weight-bolder">
              Berlangganan akan segara berakhir
            </h4>
            <p class="text-dark-50 font-weight-bold mt-3">
              Akan berakhir dalam 30 hari. segera lakukan pembayaran.
            </p>
          </div>
          <a href="#" class="btn btn-link btn-link-warning font-weight-bold"
            >Aktivasi Sekarang
            <span class="svg-icon svg-icon-lg svg-icon-warning">
              <!--begin::Svg Icon | path:assets/media/svg/icons/Navigation/Arrow-right.svg-->
              <inline-svg src="media/svg/icons/Navigation/Arrow-right.svg" />
              <!--end::Svg Icon-->
            </span></a
          >
        </div>
        <div class="position-absolute right-0 bottom-0 mr-5 overflow-hidden">
          <img
            src="media/svg/humans/custom-13.svg"
            class="max-h-200px max-h-xl-275px mb-n20"
            alt=""
          />
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "BannerAktivasi",
};
</script>
